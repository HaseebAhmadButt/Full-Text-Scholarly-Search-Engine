package com.solr.Entities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EntitiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
